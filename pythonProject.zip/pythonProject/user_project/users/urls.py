from django.urls import path
# from .views import homePageView
from .views import HomePageView, InfoPageView, ProfilePageView


# urlpatterns = [path('', homePageView, name='home'),]
urlpatterns = [path('', HomePageView.as_view(), name='home'),
path('info/', InfoPageView.as_view(), name='info'),
path('profile/', ProfilePageView.as_view(), name='profile'),]