# from django.http import HttpResponse
from django.views.generic import TemplateView

class HomePageView(TemplateView):
    template_name = 'home.html'


class ProfilePageView(TemplateView):
    template_name = 'profile.html'


class InfoPageView(TemplateView):
    template_name = 'info.html'


# def homePageView(request):
#     return HttpResponse('Hi,welcome!')